package com.newskyer.meetingpad.fileselector.fragment;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.newskyer.meetingpad.R;
import com.newskyer.meetingpad.fileselector.activity.FileSelectActivity;
import com.newskyer.meetingpad.fileselector.file.adapter.FileListAdapter;
import com.newskyer.meetingpad.fileselector.file.model.FileInfo;
import com.newskyer.meetingpad.fileselector.util.LocalFileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @author liziyang
 * @since 2018/1/24
 */
public class CategoryFragment extends Fragment implements CustomFragmentTabHost.BaseFragment {

    private ListView listViewCategory;


    private List<FileInfo> fileInfoList = fileInfoList = new ArrayList<>();
    private FileListAdapter adapter;

    private String mLocalDevice = "";
    private String currentDir = "Local Device";//getResources().getString(R.string.current_dir);
    private TextView textViewCurrentPath;

    private View imageViewBack;

    private String fileInnerPath;
    private FileInfo fileInfoInner;
    private static String setDir = "";
    public static void setDir(String path) {
        setDir = path;
    }

    private List<FileInfo> fileInfoListUSB = new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        ButterKnife.bind(this, view);
        listViewCategory = (ListView) view.findViewById(R.id.list_file_selector_category);
        textViewCurrentPath = (TextView) view.findViewById(R.id.text_file_current_path);
        imageViewBack = view.findViewById(R.id.image_back_to_parent);
//        mLocalDevice = currentDir = getResources().getString(R.string.current_dir);
        view.findViewById(R.id.view_back_to_parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToParent();
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adapter = new FileListAdapter(getContext(), R.layout.item_file_list, fileInfoList, FileListAdapter.TYPE_EXPLORER);
        listViewCategory.setAdapter(adapter);
        listViewCategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 判断文件类型
                FileInfo fileInfo = fileInfoList.get(position);
                if (fileInfo != null) {
                    if (fileInfo.getFileType() == FileInfo.FILE_TYPE_DIR ||
                            fileInfo.getFileType() == FileInfo.FILE_TYPE_INNER_DISK ||
                            fileInfo.getFileType() == FileInfo.FILE_TYPE_U_DISK) {
                        // 目录跳转
                        currentDir = fileInfo.getFilePath();
                        update();
                    } else {
                        // 选择文件，返回路径
                        Intent intent = new Intent();
                        intent.putExtra(FileSelectActivity.FILE_PATH, fileInfo.getFilePath());
                        getActivity().setResult(Activity.RESULT_OK, intent);
                        getActivity().setIntent(intent);
                        getActivity().finish();
                    }
                }
            }
        });

        mLocalDevice = currentDir = getResources().getString(R.string.current_dir);
        // 获取内置存储
        File fileInner = LocalFileUtil.getInnerStorage();
        fileInnerPath = fileInner.getAbsolutePath();
        fileInfoInner = new FileInfo();
        if (!fileInnerPath.equals("")) {
            fileInfoInner.setFileType(FileInfo.FILE_TYPE_INNER_DISK);
            fileInfoInner.setFileName(getResources().getString(R.string.inner_storage));
            fileInfoInner.setFilePath(fileInnerPath);
        }
        fileInfoList.add(fileInfoInner);

        fileInfoListUSB.clear();
        fileInfoListUSB.addAll(LocalFileUtil.getUSBDevicesL(getContext()));
        fileInfoList.addAll(fileInfoListUSB);

        adapter.notifyDataSetChanged();

        if (setDir != null && !setDir.isEmpty()) {
            Log.d("paint", "set dir: " + setDir);
            if (new File(setDir).exists()) {
                currentDir = setDir;
                update();
            }
        }

    }


    private void updateCurrentPath() {
        if (currentDir.contains(fileInnerPath)) {
            // 内置存储
            textViewCurrentPath.setText(currentDir.replace(fileInnerPath, getResources().getString(R.string.inner_storage)));
        } else {
            textViewCurrentPath.setText(currentDir);
        }
    }

    private void setBackIconVisible(boolean v) {
        imageViewBack.setVisibility(v ? View.VISIBLE : View.GONE);
    }


    public void backToParent() {
        // 返回上一级
        // 还要加上U盘
        if (imageViewBack.getVisibility() == View.VISIBLE) {
            if (LocalFileUtil.isRootDir(currentDir)) {
                // 某个设备的顶层目录，返回设备列表
                updateDevices();
                setBackIconVisible(false);
            } else {
                currentDir = LocalFileUtil.getParentPath(currentDir);
                update();
            }
        }
    }

    private void update() {
        List<FileInfo> fileInfoListTemp = LocalFileUtil.getFileList(currentDir, ((FileSelectActivity) getActivity()).getSelectType());
        fileInfoList.clear();
        fileInfoList.addAll(fileInfoListTemp);
        adapter.notifyDataSetChanged();
        updateCurrentPath();
        setBackIconVisible(true);
    }


    public void updateDevices() {
        currentDir = mLocalDevice;//getResources().getString(R.string.current_dir);
        updateCurrentPath();
        fileInfoList.clear();
        fileInfoList.add(fileInfoInner);

        fileInfoListUSB.clear();
        fileInfoListUSB.addAll(LocalFileUtil.getUSBDevicesL(getContext()));
        fileInfoList.addAll(fileInfoListUSB);

        adapter.notifyDataSetChanged();
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onUpdate() {
        updateDevices();
    }
}
