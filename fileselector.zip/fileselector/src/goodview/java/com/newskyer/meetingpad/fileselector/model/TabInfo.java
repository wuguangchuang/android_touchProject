package com.newskyer.meetingpad.fileselector.model;

/**
 * @author liziyang
 * @since 2018/1/26
 */
public class TabInfo {
    private String tab;
    private Class cls;
    private int resource;

    public TabInfo(String tab, Class cls, int resource) {
        this.tab = tab;
        this.cls = cls;
        this.resource = resource;
    }

    public String getTab() {
        return tab;
    }

    public void setTab(String tab) {
        this.tab = tab;
    }

    public Class getCls() {
        return cls;
    }

    public void setCls(Class cls) {
        this.cls = cls;
    }

    public int getResource() {
        return resource;
    }

    public void setResource(int resource) {
        this.resource = resource;
    }
}
