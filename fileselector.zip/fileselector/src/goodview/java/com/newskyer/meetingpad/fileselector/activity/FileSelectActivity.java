package com.newskyer.meetingpad.fileselector.activity;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import com.newskyer.meetingpad.R;
import com.newskyer.meetingpad.fileselector.fragment.CategoryFragment;
import com.newskyer.meetingpad.fileselector.fragment.CustomFragmentTabHost;
import com.newskyer.meetingpad.fileselector.fragment.DocFragment;
import com.newskyer.meetingpad.fileselector.fragment.MusicFragment;
import com.newskyer.meetingpad.fileselector.fragment.NccFragment;
import com.newskyer.meetingpad.fileselector.fragment.PictureFragment;
import com.newskyer.meetingpad.fileselector.fragment.VideoFragment;
import com.newskyer.meetingpad.fileselector.model.TabInfo;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.internal.Utils;

/**
 * @author liziyang
 * @since 2018/1/24
 */
public class FileSelectActivity extends AppCompatActivity {

    private int selectType;
    public static final int SELECT_TYPE_ALL = 0;
    public static final int SELECT_TYPE_PICTURE = 1;
    public static final int SELECT_TYPE_MUSIC = 2;
    public static final int SELECT_TYPE_VIDEO = 3;
    public static final int SELECT_TYPE_DOC = 4;
    public static final int SELECT_TYPE_NCC = 5;
    public static final int SELECT_TYPE_ALL_EXCEPT_NCC = 6;
    public static final String SELECT_TYPE = "select_type";
    public static final String SELECT_OPEN  = "select_open";
    public static final String SELECT_DIR = "select_dir";

    public static final int REQUEST_CODE = 2222;
    public static final String FILE_PATH = "file_path";

    @BindView(android.R.id.tabhost)
    CustomFragmentTabHost fragmentTabHost;

    private static String STRING_CATEGORY = "目录";
    private static String STRING_PICTURE = "图片";
    private static String STRING_MUSIC = "音乐";
    private static String STRING_VIDEO = "视频";
    private static String STRING_DOC = "文档";
    private static String STRING_NCC = "笔迹";

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(usbDiskReceiver);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        Log.i("pa", "key:" + keyCode);
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
        }
        return super.onKeyUp(keyCode, event);
    }

    private boolean mActionView = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_select);

        ButterKnife.bind(this);
        Resources resources = getResources();
        STRING_CATEGORY = resources.getString(R.string.category);
        STRING_PICTURE = resources.getString(R.string.picture);
        STRING_MUSIC = resources.getString(R.string.music);
        STRING_VIDEO = resources.getString(R.string.video);
        STRING_DOC = resources.getString(R.string.doc);
        STRING_NCC = resources.getString(R.string.ncc);

        LayoutInflater layoutInflater = LayoutInflater.from(this);

        fragmentTabHost.setup(this, getSupportFragmentManager(), R.id.layout_file_content);

        TabInfo tabInfoAll = new TabInfo(STRING_CATEGORY, CategoryFragment.class, R.drawable.tab_category_selector);
        TabInfo tabInfoPic = new TabInfo(STRING_PICTURE, PictureFragment.class, R.drawable.tab_picture_selector);
        TabInfo tabInfoMusic = new TabInfo(STRING_MUSIC, MusicFragment.class, R.drawable.tab_music_selector);
        TabInfo tabInfoVideo = new TabInfo(STRING_VIDEO, VideoFragment.class, R.drawable.tab_video_selector);
        TabInfo tabInfoDoc = new TabInfo(STRING_DOC, DocFragment.class, R.drawable.tab_doc_selector);
        TabInfo tabInfoNcc = new TabInfo(STRING_NCC, NccFragment.class, R.drawable.tab_ncc_selector);

        String dir = getIntent().getStringExtra(SELECT_DIR);
        Log.d("paint", "dir = " + dir);
        if (dir != null && !dir.isEmpty())
            CategoryFragment.setDir(dir);

        List<TabInfo> tabInfoList = new ArrayList<>();
        tabInfoList.add(tabInfoAll);
        mActionView = getIntent().getBooleanExtra(SELECT_OPEN, false);
        selectType = getIntent().getIntExtra(SELECT_TYPE, SELECT_TYPE_ALL);
        switch (selectType) {
            case SELECT_TYPE_ALL_EXCEPT_NCC:
                tabInfoList.add(tabInfoPic);
                tabInfoList.add(tabInfoMusic);
                tabInfoList.add(tabInfoVideo);
                tabInfoList.add(tabInfoDoc);
                break;
            case SELECT_TYPE_ALL:
                tabInfoList.add(tabInfoPic);
                tabInfoList.add(tabInfoMusic);
                tabInfoList.add(tabInfoVideo);
                tabInfoList.add(tabInfoDoc);
                tabInfoList.add(tabInfoNcc);
                break;
            case SELECT_TYPE_PICTURE:
                tabInfoList.add(tabInfoPic);
                break;
            case SELECT_TYPE_MUSIC:
                tabInfoList.add(tabInfoMusic);
                break;
            case SELECT_TYPE_VIDEO:
                tabInfoList.add(tabInfoVideo);
                break;
            case SELECT_TYPE_DOC:
                tabInfoList.add(tabInfoDoc);
                break;
            case SELECT_TYPE_NCC:
                tabInfoList.add(tabInfoNcc);
                break;
        }

        for (TabInfo tabInfo : tabInfoList) {
            View view = layoutInflater.inflate(R.layout.layout_selector_tab, null);
            ImageView imageView = (ImageView) view.findViewById(R.id.image_file_tab);
            TextView textView = (TextView) view.findViewById(R.id.text_file_tab);
            imageView.setImageResource(tabInfo.getResource());
            textView.setText(tabInfo.getTab());
            view.setTag(tabInfo.getTab());

            TabHost.TabSpec tabSpec = fragmentTabHost.newTabSpec(tabInfo.getTab()).setIndicator(view);
            fragmentTabHost.addTab(tabSpec, tabInfo.getCls(), null);
        }
        if (selectType != SELECT_TYPE_ALL) {
            fragmentTabHost.setCurrentTabByTag(tabInfoList.get(tabInfoList.size() - 1).getTab());
        }
        fragmentTabHost.getTabWidget().setDividerDrawable(null);
        IntentFilter intentFilterUSB = new IntentFilter();
        intentFilterUSB.addAction(Intent.ACTION_MEDIA_MOUNTED);
        intentFilterUSB.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
        intentFilterUSB.addAction(Intent.ACTION_MEDIA_REMOVED);
        intentFilterUSB.addAction(Intent.ACTION_MEDIA_EJECT);
        intentFilterUSB.addAction(Intent.ACTION_MEDIA_SCANNER_FINISHED);
        intentFilterUSB.addDataScheme("file");
        registerReceiver(usbDiskReceiver, intentFilterUSB);

    }
    public void finish() {
        if (mActionView) {
            Intent data = getIntent();
            String path = data.getStringExtra(FileSelectActivity.FILE_PATH);
            if (path == null || path.isEmpty()) {
                super.finish();
                return;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            String type = null;
            int index = path.lastIndexOf(".");
            if (index < 0) {
                super.finish();
                return;
            }
            String ext = path.substring(index + 1);
            Uri uri = Uri.parse("file://" + path);
            if (type == null && path.endsWith(".ncc")) {
                uri = Uri.parse(URLEncoder.encode("file://" + path));
                intent.putExtra("encode", true);
                type = "note/ncc";
            } else {
                type = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(ext.toLowerCase());
            }
            if (type != null) {
                PackageManager pm = getPackageManager();
                Intent check = new Intent();
                if (type.startsWith("image")) {
                    ComponentName cn = new ComponentName(
                        "com.android.gallery3d", "com.android.gallery3d.app.GalleryActivity");
                    check.setComponent(cn);
                    if (pm.resolveActivity(check, 0) != null) {
                        intent.setComponent(cn);
                    }
                } else if (type.startsWith("text/plain") ||
                    type.startsWith("application/vnd.openxmlformats-officedocument") ||
                    type.startsWith("application/pdf")) {
                    ComponentName cn = new ComponentName(
                        "cn.wps.moffice_eng", "cn.wps.moffice.documentmanager.PreStartActivity2");
//                    intent.setComponent(cn);
                    check.setComponent(cn);
                    if (pm.resolveActivity(check, 0) != null) {
                        intent.setComponent(cn);
                    }
                } else if (type.startsWith("audio/")) {
                    ComponentName cn = new ComponentName(
                        "com.jrm.localmm", "com.jrm.localmm.ui.music.MusicPlayerActivity");
//                    intent.setComponent(cn);
                    check.setComponent(cn);
                    if (pm.resolveActivity(check, 0) != null) {
                        intent.setComponent(cn);
                    }
                } else if (type.startsWith("video/")) {
                    ComponentName cn = new ComponentName(
                        "com.jrm.localmm", "com.jrm.localmm.ui.video.VideoPlayerActivity");
//                    intent.setComponent(cn);
                    check.setComponent(cn);
                    if (pm.resolveActivity(check, 0) != null) {
                        intent.setComponent(cn);
                    }
                }
                Log.d("123", "check = " + pm.resolveActivity(check, 0));

            }
            Log.d("123", "open all:" + type + "  @ " + path + ",, " + ext);
            if (Build.VERSION.SDK_INT >= 24) { // 24 is N
                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());
            } else {
            }
            intent.setDataAndType(uri, type);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(intent);
            } catch (Exception e) {
            }
        }
        super.finish();
    }
    private BroadcastReceiver usbDiskReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
//            Log.d("2222", "╔════════════════════════════════════════════════");
//            Log.d("2222", "║    action : " + intent.getAction());
//            Log.d("2222", "╚════════════════════════════════════════════════");
            switch (intent.getAction()) {
                case Intent.ACTION_MEDIA_SCANNER_FINISHED:
                case Intent.ACTION_MEDIA_MOUNTED:
                    // 挂载
                case Intent.ACTION_MEDIA_REMOVED:
                    // 移除

//                    if (intent.getAction().equals(Intent.ACTION_MEDIA_MOUNTED)) {
//                        Log.d("2222", "╔════════════════════════════════════════════════");
//                        Log.d("2222", "║    挂载");
//                        Log.d("2222", "╚════════════════════════════════════════════════");
//                    } else {
//                        Log.d("2222", "╔════════════════════════════════════════════════");
//                        Log.d("2222", "║    卸载");
//                        Log.d("2222", "╚════════════════════════════════════════════════");
//                    }

//                    if (currentDir.equals("当前设备")) {
                        // 更新
                        fragmentTabHost.updateDevices();
//                    }
                    break;
            }
        }
    };

    public int getSelectType() {
        return selectType;
    }
//    public static final boolean is811 = "bigfish".equals(Utils.getSystemProperty("ro.board.platform", ""));
}
